#include "Menu.h"
#define LEVEL1_WIDTH 14
#define LEVEL1_HEIGHT 8
//unsigned int level1_data[] =
//{
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 3, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
// 3, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2,
// 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2
//};
//Entity player;
void Menu::Initialize() {
	//glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	fontTextureID = Util::LoadTexture("pixel_font.png");
	//player.entityType = PLAYER;
	//player.isStatic = false;
	//player.width = 2.0f;
	//player.height = 1.5f;
	//player.spriteWidth = 2.5f;
	//player.spriteHeight = 2.0f;
	//player.lives = 3;
	//player.position = glm::vec3(4.75, -3.4, 0);
	//player.velocity.x = 0.0f;
	//player.spritePosition = player.position;
	//player.acceleration = glm::vec3(0, 0, 0);
	////state.player.textureID = Util::LoadTexture("assets/dog2.png");
	////player animation
	//player.textureID = Util::LoadTexture("assets/dog2.png");
	//player.textureIDIdle = Util::LoadTexture("assets/dog-walk-sheet2.png");
	//player.textureIDWalk = Util::LoadTexture("assets/dog-walk-sheet2.png");
	//player.spriteWidth = 2.8f;
	//player.spriteHeight = 2.5f;
	//player.cols = 3; //texture cols
	//player.rows = 4; //texture rows
	//player.colsWalk = 4; //texture cols
	//player.rowsWalk = 4; //texture rows
	//player.walkRight = new int[7]{ 0,1,2,3,4,5,6 };
	//player.walkLeft = new int[7]{ 0,1,2,3,4,5,6 };
	//player.idleLeft = new int[7]{ 0,1,2,3,4,5,6 };
	//player.idleRight = new int[7]{ 0,1,2,3,4,5,6 };
	//player.currentAnim = player.walkRight;
	//player.animFrames = 7;
	//player.animFramesWalk = 7;
	//player.animationState = WALKING;

	state.nextLevel = -1;
}
void Menu::Update(float deltaTime) {
	//state.player.velocity.x = 3.0f;
	//player.UpdateAnimation(deltaTime);

	//if (state.player.position.x > 12) {
	//	state.nextLevel = 1;
	//}
	//if (state.player.lives == 0) {
	//	state.nextLevel = 4;
	//}
}
void Menu::Render(ShaderProgram* program) {
	/*state.map->Render(program);*/
	//player.Render(program);
	Util::DrawText(program, fontTextureID, "DOG.", 1.0f, -0.1f, glm::vec3(3.8f, -1.75f, 0));
	Util::DrawText(program, fontTextureID, "Press enter to start!", 0.4f, -0.05f, glm::vec3(1.7f, -5.0f, 0));
}