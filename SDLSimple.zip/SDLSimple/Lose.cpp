#include "Lose.h"
#define LEVEL1_WIDTH 14
#define LEVEL1_HEIGHT 8

void Lose::Initialize() {
	loseSound = Mix_LoadWAV("sounds/lose.wav");
	Mix_PlayChannel(-1, loseSound, 0); //play chunk once and do not loop
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	fontTextureID = Util::LoadTexture("pixel_font.png");
	state.nextLevel = -1;
}
void Lose::Update(float deltaTime) {
}
void Lose::Render(ShaderProgram* program) {
	Util::DrawText(program, fontTextureID, "You Lose!", 1.0f, -0.1f, glm::vec3(1.8f, -1.75f, 0));
	Util::DrawText(program, fontTextureID, "Press enter for menu.", 0.4f, -0.05f, glm::vec3(1.7f, -5.0f, 0));
}