#pragma once
#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

//game state defined at bottom due to cyclic association
class GameState; 
enum GameMode { GAME_PLAYING, GAME_WIN, GAME_LOSE };

enum EntityType { PLAYER, CHEESE, CAT };

class Entity {
public:

	EntityType entityType;
	bool isStatic;
	bool isActive;
	//holds pointer to game state
	GameState *gameState;
	
	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 acceleration;

	float width;
	float height;
	float spriteWidth;
	float spriteHeight;

	float speed;

	//handling animation. 
	GLuint textureID;
	int cols;
	int rows;
	int *walkRight;
	int *walkLeft;
	int *currentAnim;
	int animFrames;
	int animIndex;
	float animTime;


	Entity(); //constructor

	//gamestate methods
	void setGameState(GameState *gs);
	void setGameMode(GameMode mode);
	GameMode getGameMode();
	//other methods
	bool CheckCollision(Entity other);
	void CheckCollisionsX(Entity *objects, int objectCount);
	void CheckCollisionsY(Entity *objects, int objectCount);

	void Update(float deltaTime, Entity *objects, int objectCount);
	void Render(ShaderProgram *program);
	void DrawSpriteFromTextureAtlas(ShaderProgram *program, int index);
	void Jump();

	//collision flags
	bool collidedTop;
	bool collidedBottom;
	bool collidedRight;
	bool collidedLeft;

};



class GameState {
public:
	Entity player;
	Entity *platforms;
	GameMode gameMode = GAME_PLAYING;
};

