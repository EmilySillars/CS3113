#include "Level2.h"
#define LEVEL2_WIDTH 30 //36
#define LEVEL2_HEIGHT 8 //8
unsigned int level2_data[] =
{
	//  2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,	
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 41, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 40, 41,
	 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 1, 0, 0, 0, 0, 18, 19, 0, 9, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 2,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 23, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
	 0, 38, 39, 0, 40, 41, 42, 0, 16, 0, 33, 0, 0, 1, 1, 1, 1, 0, 17, 0, 0, 38, 0, 1, 1, 1, 0, 0, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
};


unsigned int level2_fg2[] =
{
	//  2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,	
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 25, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 27,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 7, 4, 5, 6, 7, 4, 5, 6, 0, 0, 5, 6, 7, 4, 5, 6, 7, 0, 0,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0,
	 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
};

void Level2::initializePlayer() {
	state.player.entityType = PLAYER;
	state.player.isStatic = false;
	state.player.width = 2.0f;
	state.player.height = 1.5f;
	state.player.spriteWidth = 2.5f;
	state.player.spriteHeight = 2.0f;
	state.player.lives = 3;
	state.player.position = glm::vec3(2, 5, 0);
	state.player.acceleration = glm::vec3(0, -9.81f, 0);
	//player animation
	state.player.textureID = Util::LoadTexture("assets/dog-idle-sheet2.png");
	state.player.textureIDIdle = Util::LoadTexture("assets/dog-idle-sheet2.png");
	state.player.textureIDWalk = Util::LoadTexture("assets/dog-walk-sheet2.png");
	state.player.spriteWidth = 2.8f;
	state.player.spriteHeight = 2.5f;
	state.player.cols = 3; //texture cols
	state.player.rows = 4; //texture rows
	state.player.colsWalk = 4; //texture cols
	state.player.rowsWalk = 4; //texture rows
	state.player.walkRight = new int[7]{ 0,1,2,3,4,5,6 };
	state.player.walkLeft = new int[7]{ 11,10,9,8,15,14,13 };
	state.player.idleLeft = new int[5]{ 8,7,6,11,10 };
	state.player.idleRight = new int[5]{ 0,1,2,3,4 };
	state.player.currentAnim = state.player.idleRight;
	state.player.animFrames = 5;
	state.player.animFramesWalk = 5;
	state.player.animationState = IDLE;
}

void Level2::initializeEnemies() {
	GLuint enemyTextureID = Util::LoadTexture("assets/accordionSheet.png");
	GLuint enemyTextureIDBlue = Util::LoadTexture("assets/accordionSheet_blue.png");
	GLuint enemyTextureIDOrange = Util::LoadTexture("assets/accordionSheet_orange.png");
	GLuint enemyTextureIDPink = Util::LoadTexture("assets/accordionSheet_pink.png");
	GLuint enemyTextureIDPurple = Util::LoadTexture("assets/accordionSheet_purple.png");
	state.enemies = enems;
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].entityType = ENEMY;
		state.enemies[i].aiType = ACCORDION;
		state.enemies[i].aiState = FLAT;
		state.enemies[i].isStatic = false;
		state.enemies[i].textureID = enemyTextureIDPink;
		state.enemies[i].textureIDIdle = enemyTextureIDPink;
		state.enemies[i].textureIDWalk = enemyTextureIDPink;
		state.enemies[i].height = 3.2f;
		state.enemies[i].width = 0.5f;
		state.enemies[i].spriteWidth = 1.0f;
		state.enemies[i].spriteHeight = 2.0f;
		state.enemies[i].position = glm::vec3(13.0f, -5.45f, 0);; //glm::vec3(5.0f, -5.20f, 0);
		//animation
		state.enemies[i].spritePosition =
			glm::vec3(state.enemies[i].position.x, state.enemies[i].position.y + state.enemies[i].accordionSpriteOffset, 0);
		state.enemies[i].speed = 0.1; //animation speed 
		state.enemies[i].cols = 3; //texture cols
		state.enemies[i].rows = 4; //texture rows
		state.enemies[i].idleLeft = new int[10]{ 0,0,0,0,0,0,0,0,0,0 }; //just one frame (FLAT)
		state.enemies[i].walkRight = new int[10]{ 0,1,2,3,4,5,6,7,8,9 }; //expanding
		state.enemies[i].idleRight = new int[10]{ 9,9,9,9,9,9,9,9,9,9 }; //just one frame (EXPANDED)
		state.enemies[i].walkLeft = new int[10]{ 9,8,7,6,5,4,3,2,1,0 }; //shrinking
		state.enemies[i].currentAnim = state.enemies[i].walkRight;
		state.enemies[i].animFrames = 10;
		state.enemies[i].aiType = ACCORDION;
		state.enemies[i].aiState = EXPANDING;
		state.enemies[i].timer = 0;
	}
	state.enemies[1].position = glm::vec3(22.0f, -6.45f, 0);; //glm::vec3(5.0f, -5.20f, 0);
	state.enemies[1].spritePosition =
		glm::vec3(state.enemies[1].position.x, state.enemies[1].position.y + state.enemies[1].accordionSpriteOffset, 0);
	state.enemies[1].textureIDIdle = enemyTextureIDPink;
	state.enemies[1].textureIDWalk = enemyTextureIDPink;
	state.enemies[1].textureID = enemyTextureIDPink;

	state.enemies[2].position = glm::vec3(25.0f, -5.45f, 0);; //glm::vec3(5.0f, -5.20f, 0);
	state.enemies[2].spritePosition =
		glm::vec3(state.enemies[2].position.x, state.enemies[2].position.y + state.enemies[2].accordionSpriteOffset, 0);
	state.enemies[2].timer = 5;
	state.enemies[2].textureIDIdle = enemyTextureIDPurple;
	state.enemies[2].textureIDWalk = enemyTextureIDPurple;
	state.enemies[2].textureID = enemyTextureIDPurple;
}

void Level2::Initialize() {
	cameraXMax = 24.0f;
	cameraXMin = 5.0f;
	glClearColor(0.0f / 255.0f, 0.0f / 255.0f, 0.0f / 255.0f, 1.0f);
	fontTextureID = Util::LoadTexture("pixel_font.png");
	GLuint mapTextureID = Util::LoadTexture("assets/test2.png"); //tileset4_test_72 tileset4_test_wide
	state.map = new Map(LEVEL2_WIDTH, LEVEL2_HEIGHT, level2_data, mapTextureID, 1.0f, 4, 11);
	state.fg_2 = new Map(LEVEL2_WIDTH, LEVEL2_HEIGHT, level2_fg2, mapTextureID, 1.0f, 4, 11);
	initializePlayer();
	textPosition = glm::vec3(6.5f, -0.5f, 0);
	textDistanceFromPlayer = glm::vec3(textPosition.x - state.player.position.x - 3, textPosition.y - state.player.position.y, 1.0f);
	initializeEnemies();
	state.nextLevel = -1;

}
void Level2::Update(float deltaTime) {
	state.player.Update(deltaTime, state.player, state.enemies, ENEMY_COUNT, state.map);
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].Update(deltaTime, state.player, NULL, 0, state.map);
	}
	if (state.player.position.x < 0) {
		state.player.position.x = 0;
	}
	if (state.player.position.x > 28) {
		state.nextLevel = 2;
	}
	if (state.player.lives == 0) {
		state.nextLevel = 4;
	}
}
void Level2::Render(ShaderProgram* program) {
	state.map->Render(program);
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].Render(program);
	}
	state.player.Render(program);
	//state.fg_2->Render(program); //commenting out because of rendering errors
	drawInfo(program);
}

void Level2::drawInfo(ShaderProgram* program) {
	std::ostringstream lives;
	lives << "Lives: " << state.player.lives;
	std::string str = lives.str();
	if (state.player.position.x > cameraXMin) {
		if (state.player.position.x > cameraXMax) {
			Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, glm::vec3(cameraXMax + textDistanceFromPlayer.x,
				textPosition.y, 1.0f));
		}
		else {
			Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, glm::vec3(state.player.position.x + textDistanceFromPlayer.x,
				textPosition.y, 1.0f));
		}
	}
	else {
		Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, textPosition);
	}
}