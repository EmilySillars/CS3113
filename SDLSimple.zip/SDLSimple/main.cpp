/*
Emily Sillars
Game Programming
Hw #2: Pong!
9/29/19
*/
#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "entity.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

SDL_Window* displayWindow;
//flags
bool gameIsRunning = true;
bool win = false;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrixLeft, modelMatrixRight, modelMatrixBall, projectionMatrix;

//paddles
glm::vec3 paddleLeft_position = glm::vec3(-4.5, 0, 0);
glm::vec3 paddleLeft_movement = glm::vec3(0, 0, 0);
glm::vec3 paddleRight_position = glm::vec3(4.5, 0, 0);
glm::vec3 paddleRight_movement = glm::vec3(0, 0, 0);

//ball
glm::vec3 ball_position = glm::vec3(0.0, 0, 0);
glm::vec3 ball_movement = glm::vec3(2.2, 1.5, 0);

//textures
GLuint playerTextureID; //paddles
GLuint ballTextureID; //ball

//function declarations
//paddles
void movePaddle_Left(float deltaTime);
void movePaddle_Right(float deltaTime);
void drawPaddle_Left(glm::mat4 modelMatrixLeft);
void drawPaddle_Right(glm::mat4 modelMatrixRight);
void checkPaddleLeftInput(const Uint8 *keys);
void checkPaddleRightInput(const Uint8 *keys);
//ball
void checkCollisionBall();
void drawBall(glm::mat4 modelMatrixBall);
void moveBall(float deltaTime);
//collision detection
bool detectBoxCollision(glm::vec3 box1pos, float box1Length, float box1Height,
	glm::vec3 box2pos, float box2Length, float box2Height);

GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	stbi_image_free(image);
	return textureID;
}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Pong!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
	glewInit();
#endif

	glViewport(0, 0, 640, 480);

	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");

	playerTextureID = LoadTexture("fork.png");
	ballTextureID = LoadTexture("broccoli.png");

	viewMatrix = glm::mat4(1.0f);
	modelMatrixLeft = glm::mat4(1.0f);
	modelMatrixRight = glm::mat4(1.0f);
	modelMatrixBall = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

	glUseProgram(program.programID);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
}



void ProcessInput() {
	paddleLeft_movement = glm::vec3(0, 0, 0);
	paddleRight_movement = glm::vec3(0, 0, 0);
	
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
		case SDL_WINDOWEVENT_CLOSE:
			gameIsRunning = false;
			break;
		}
	}

	// Check for pressed/held keys below
	const Uint8 *keys = SDL_GetKeyboardState(NULL);
	checkPaddleLeftInput(keys);
	checkPaddleRightInput(keys);
}

float lastTicks = 0;

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;
	if (!win) {
		movePaddle_Left(deltaTime);
		movePaddle_Right(deltaTime);
		checkCollisionBall();
		moveBall(deltaTime);
	}
}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);

	drawPaddle_Left(modelMatrixLeft);
	drawPaddle_Right(modelMatrixRight);
	drawBall(modelMatrixBall);
	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		Update();
		Render();
	}

	Shutdown();
	return 0;
}



//check collision ball
void checkCollisionBall() {
	//check if colliding with ceiling or floor
	//and change direction accordingly
	if (ball_position.y >= 3.5 &&
		ball_movement.y > 0){
		ball_movement.y *= -1;
	}

	if (ball_position.y <= -3.5 &&
		ball_movement.y < 0) {
		ball_movement.y *= -1;
	
	}

	//colliding with left or right paddle? Reverse x-direction!
	if (detectBoxCollision(paddleLeft_position, 1, 1, ball_position, 1, 1) &&
		ball_movement.x < 0) {
		ball_movement.x *= -1;
	} 
	if(detectBoxCollision(paddleRight_position, 1, 1, ball_position, 1, 1) &&
		ball_movement.x > 0) {
		ball_movement.x *= -1;
	}

	//win condition
	if (ball_position.x > 5.0 ||
		ball_position.x < -5.0) {
		win = true;
		glClearColor(188.0f / 255.0f, 111.0f / 255.0f, 201.0f / 255.0f, 1.0f);
	}

}

//general box collision detection
bool detectBoxCollision(glm::vec3 box1pos, float box1Length, float box1Height, 
						glm::vec3 box2pos, float box2Length, float box2Height) {
	float xDiff = fabs(box1pos.x - box2pos.x);
	float yDiff = fabs(box1pos.y - box2pos.y);
	float Xdistance = xDiff - (box1Length + box2Length)/2;
	float Ydistance = yDiff - (box1Height + box2Height)/2;
	return ((Xdistance < 0) && (Ydistance < 0));
}

//check paddle input
void checkPaddleLeftInput(const Uint8 *keys) {
	if (keys[SDL_SCANCODE_W])
	{
		if (paddleLeft_position.y >= 3.5) {
			paddleLeft_movement.y = 0;
		}
		else {
			paddleLeft_movement.y = 3;
		}
	}
	else if (keys[SDL_SCANCODE_S])
	{
		if (paddleLeft_position.y <= -3.5) {
			paddleLeft_movement.y = 0;
		}
		else {
			paddleLeft_movement.y = -3;
		}
	}
}

void checkPaddleRightInput(const Uint8 *keys) {
	if (keys[SDL_SCANCODE_UP])
	{
		if (paddleRight_position.y >= 3.5) {
			paddleRight_movement.y = 0;
		}
		else {
			paddleRight_movement.y = 3;
		}
	}
	else if (keys[SDL_SCANCODE_DOWN])
	{
		if (paddleRight_position.y <= -3.5) {
			paddleRight_movement.y = 0;
		}
		else {
			paddleRight_movement.y = -3;
		}
	}
}

//move ball
void moveBall(float deltaTime) {
	ball_position += ball_movement * deltaTime;
	modelMatrixBall = glm::mat4(1.0f);
	modelMatrixBall = glm::translate(modelMatrixBall, ball_position);
}
//move paddles
void movePaddle_Left(float deltaTime) {
	paddleLeft_position += paddleLeft_movement * deltaTime;
	modelMatrixLeft = glm::mat4(1.0f);
	modelMatrixLeft = glm::translate(modelMatrixLeft, paddleLeft_position);
}
void movePaddle_Right(float deltaTime) {
	paddleRight_position += paddleRight_movement * deltaTime;
	modelMatrixRight = glm::mat4(1.0f);
	modelMatrixRight = glm::translate(modelMatrixRight, paddleRight_position);
}

//draw paddles
void drawPaddle_Left(glm::mat4 modelMatrixLeft) {
	program.SetModelMatrix(modelMatrixLeft);

	float vertices[] = { -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 };
	float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, playerTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);
}

void drawPaddle_Right(glm::mat4 modelMatrixRight) {
	program.SetModelMatrix(modelMatrixRight);

	float vertices2[] = { -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 };
	float texCoords2[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, playerTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices2);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords2);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);
}

//draw ball
void drawBall(glm::mat4 modelMatrixBall) {
	program.SetModelMatrix(modelMatrixBall);

	float vertices[] = { -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 };
	float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, ballTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);
}
