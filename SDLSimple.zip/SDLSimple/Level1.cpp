#include "Level1.h"
#define LEVEL1_WIDTH 30 //36
#define LEVEL1_HEIGHT 8 //8
unsigned int level1_data[] =
{
//  2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,	
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 11, 0, 0, 0, 1, 1, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 2, 2, 0, 25, 0, 0, 2, 2, 0, 0, 34, 33, 0, 14, 15, 0, 0, 0, 1, 1, 38, 39, 0, 0,
 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 0, 0
};

unsigned int level1_fg2[] =
{
	//  2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,	
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 31, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 25, 26, 0, 0, 0, 0, 27, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0,
	 27, 24, 25, 26, 27, 24, 2, 2, 27, 12, 25, 26, 2, 2, 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 1, 1, 4, 5, 6, 7,
	 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 3, 3
};

void Level1::initializePlayer() {
	state.player.entityType = PLAYER;
	state.player.isStatic = false;
	state.player.width = 2.0f;
	state.player.height = 1.5f;
	state.player.spriteWidth = 2.5f;
	state.player.spriteHeight = 2.0f;
	state.player.lives = 3;
	state.player.position = glm::vec3(3, 0, 0); 
	state.player.acceleration = glm::vec3(0, -9.81f, 0);
	//player animation
	state.player.textureID = Util::LoadTexture("assets/dog-idle-sheet2.png");
	state.player.textureIDIdle = Util::LoadTexture("assets/dog-idle-sheet2.png");
	state.player.textureIDWalk = Util::LoadTexture("assets/dog-walk-sheet2.png");
	state.player.spriteWidth = 2.8f;
	state.player.spriteHeight = 2.5f;
	state.player.cols = 3; //texture cols
	state.player.rows = 4; //texture rows
	state.player.colsWalk = 4; //texture cols
	state.player.rowsWalk = 4; //texture rows
	state.player.walkRight = new int[7]{ 0,1,2,3,4,5,6 };
	state.player.walkLeft = new int[7]{ 11,10,9,8,15,14,13 };
	state.player.idleLeft = new int[5]{ 8,7,6,11,10 };
	state.player.idleRight = new int[5]{ 0,1,2,3,4 };
	state.player.currentAnim = state.player.idleRight;
	state.player.animFrames = 5;
	state.player.animFramesWalk = 5;
	state.player.animationState = IDLE;
}

void Level1::initializeEnemies() {
	GLuint enemyTextureID = Util::LoadTexture("assets/accordionSheet.png");
	GLuint enemyTextureIDBlue = Util::LoadTexture("assets/accordionSheet_blue.png");
	state.enemies = enems;
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].entityType = ENEMY;
		state.enemies[i].aiType = ACCORDION;
		state.enemies[i].aiState = FLAT;
		state.enemies[i].isStatic = true;
		state.enemies[i].textureID = enemyTextureID;
		state.enemies[i].textureIDIdle = enemyTextureID;
		state.enemies[i].textureIDWalk = enemyTextureID;
		state.enemies[i].height = 3.2f;
		state.enemies[i].width = 0.5f;
		state.enemies[i].spriteWidth = 1.0f;
		state.enemies[i].spriteHeight = 2.0f;
		state.enemies[i].position = glm::vec3(13.0f, -5.45f, 0);; //glm::vec3(5.0f, -5.20f, 0);
		//animation
		state.enemies[i].spritePosition =
			glm::vec3(state.enemies[i].position.x, state.enemies[i].position.y + state.enemies[i].accordionSpriteOffset, 0);
		state.enemies[i].speed = 0.1; //animation speed 
		state.enemies[i].cols = 3; //texture cols
		state.enemies[i].rows = 4; //texture rows
		state.enemies[i].idleLeft = new int[10]{ 0,0,0,0,0,0,0,0,0,0 }; //just one frame (FLAT)
		state.enemies[i].walkRight = new int[10]{ 0,1,2,3,4,5,6,7,8,9 }; //expanding
		state.enemies[i].idleRight = new int[10]{ 9,9,9,9,9,9,9,9,9,9 }; //just one frame (EXPANDED)
		state.enemies[i].walkLeft = new int[10]{ 9,8,7,6,5,4,3,2,1,0 }; //shrinking
		state.enemies[i].currentAnim = state.enemies[i].walkRight;
		state.enemies[i].animFrames = 10;
		state.enemies[i].aiType = ACCORDION;
		state.enemies[i].aiState = EXPANDING;
		state.enemies[i].timer = 0;
	}
	state.enemies[1].position = glm::vec3(22.0f, -6.45f, 0); //glm::vec3(5.0f, -5.20f, 0);
	state.enemies[1].spritePosition =
		glm::vec3(state.enemies[1].position.x, state.enemies[1].position.y + state.enemies[1].accordionSpriteOffset, 0);
	state.enemies[1].textureID = enemyTextureIDBlue;
	state.enemies[1].textureIDIdle = enemyTextureIDBlue;
	state.enemies[1].textureIDWalk = enemyTextureIDBlue;
}

void Level1::Initialize() {
	music = Mix_LoadMUS("sounds/music.mp3");
	Mix_PlayMusic(music, -1); //play music and loop forever
	Mix_VolumeMusic(3*(MIX_MAX_VOLUME /4)); //set volume from 0 10 128
	//Mix_HaltMusic(); //stop the music
	//die = Mix_LoadWAV("die.wav"); //must be 16 bit wav
	//Mix_PlayChannel(-1, bounce, 0); play chunk once and do not loop
	//Mix_Volume(-1, MIX_MAX_VOLUME / 2); //set all channels to half volume
	cameraXMax = 24.0f;
	cameraXMin = 5.0f;
	glClearColor(0.0f / 255.0f, 0.0f / 255.0f, 0.0f / 255.0f, 1.0f);
	fontTextureID = Util::LoadTexture("pixel_font.png");
	GLuint mapTextureID = Util::LoadTexture("assets/test2.png");
	state.map = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level1_data, mapTextureID, 1.0f, 4, 11);;
	state.fg_2 = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level1_fg2, mapTextureID, 1.0f, 4, 11);
	initializePlayer();
	textPosition = glm::vec3(6.5f, -0.5f, 0);
	textDistanceFromPlayer = glm::vec3 (textPosition.x - state.player.position.x-2, textPosition.y-state.player.position.y,1.0f);
	initializeEnemies();
	state.nextLevel = -1;
	
}
void Level1::Update(float deltaTime) {
	state.player.Update(deltaTime, state.player, state.enemies, ENEMY_COUNT, state.map);
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].Update(deltaTime, state.player, state.enemies, ENEMY_COUNT, state.map);
	}
	if (state.player.position.x < 0) {
		state.player.position.x = 0;
	}
	if (state.player.position.x > 28) {
		state.nextLevel = 1;
	}
	if (state.player.lives == 0) {
		state.nextLevel = 4;
	}
}
void Level1::Render(ShaderProgram* program) {
	state.map->Render(program);
	for (int i = 0; i < ENEMY_COUNT; i++) {
		state.enemies[i].Render(program);
	}
	state.player.Render(program);
	//state.fg_2->Render(program); //commenting out because of rendering errors
	drawInfo(program);	
}

void Level1 :: drawInfo(ShaderProgram* program) {
	std::ostringstream lives;
	lives << "Lives: " << state.player.lives;
	std::string str = lives.str();
	if (state.player.position.x > cameraXMin) {
		if (state.player.position.x > cameraXMax) {
			Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, glm::vec3(cameraXMax + textDistanceFromPlayer.x,
				textPosition.y, 1.0f));
		}
		else {
			Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, glm::vec3(state.player.position.x + textDistanceFromPlayer.x,
				textPosition.y, 1.0f));
		}
	}
	else {
		Util::DrawText(program, fontTextureID, str, 0.4f, -0.05f, textPosition);
	}
}