#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <vector>
#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "Entity.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

#define PLATFORM_COUNT 15
Entity platforms[PLATFORM_COUNT];
GameState state;
Entity player;
GLuint fontTextureID;

GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	stbi_image_free(image);
	return textureID;
}

void DrawText(ShaderProgram *program, GLuint fontTextureID, std::string text, float size, float spacing, glm::vec3 position) {
	float width = 1.0f / 16.0f;
	float height = 1.0f / 16.0f;

	std::vector<float> vertices;
	std::vector<float> texCoords;

	for (int i = 0; i < text.size(); i++) {
		int index = (int)text[i]; //ascii value of char

		float u = (float)(index % 16) / 16.0f;
		float v = (float)(index / 16) / 16.0f;

		texCoords.insert(texCoords.end(), { u, v + height, u + width, v + height, u + width,
											v, u, v + height, u + width, v, u, v });
		float offset = (size + spacing)*i;
		vertices.insert(vertices.end(), {   offset + (-0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (0.5f * size),
											offset + (-0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (0.5f * size),
											offset + (-0.5f *size), (0.5f * size) });
	}
	//familiar code
	glm::mat4 modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, position);
	program->SetModelMatrix(modelMatrix);

	glBindTexture(GL_TEXTURE_2D, fontTextureID);

	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices.data());
	glEnableVertexAttribArray(program->positionAttribute);

	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords.data());
	glEnableVertexAttribArray(program->texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, vertices.size() / 2.0f);

	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);

}

void initializePlayer() {
//initializing player
	state.player.gameState = &state;
	state.player.entityType = PLAYER;
	//set player's accelaration as acceleration due to gravity
	state.player.acceleration = glm::vec3(0, -0.1, 0);
	state.player.isStatic = false; //player isn't static! 
	state.player.position = glm::vec3(-3.5, 3.0, 0);
	state.player.speed = 2;
	state.player.width = 0.7f;
	state.player.height = 1.8f;
	//player animation
	state.player.textureID = LoadTexture("mouseSheet.png");
	state.player.spriteWidth = 2.0f;
	state.player.spriteHeight = 2.0f;
	state.player.cols = 2; //texture cols
	state.player.rows = 1; //texture rows
	state.player.walkRight = new int[1]{ 0 }; // just 1 frame
	state.player.walkLeft = new int[1]{ 1 }; // just 1 frame
	state.player.currentAnim = state.player.walkRight;
	state.player.animFrames = 1;
}

void initializePlatforms() {
	GLuint tileTextureID = LoadTexture("tileSet.png");
	for (int i = 0; i < PLATFORM_COUNT; i++) {
		//platforms should not move, so no acceleration due to gravity
		state.platforms[i].acceleration = glm::vec3(0, 0, 0);
		state.platforms[i].isStatic = true; //platforms are static
		//player animation
		state.platforms[i].textureID = tileTextureID;
		state.platforms[i].speed = 0;
		state.platforms[i].cols = 2; //texture cols
		state.platforms[i].rows = 1; //texture rows
		state.platforms[i].walkRight = NULL; //4 frames, and these are their indices! (walking right)
		state.platforms[i].walkLeft = NULL; //4 frames, and these are their indices! (walking right)
		state.platforms[i].currentAnim = new int[1]{ 1 }; //just one frame
		state.platforms[i].animFrames = 1;
	}
	//place first 10 platforms along floor
	float leftPos = -4.5;
	for (int i = 0; i < 10; i++) {
		state.platforms[i].position = glm::vec3(leftPos + i, -3.25, 0);
	}
	//make two small towers
	for (int i = 0; i < 3; i++) {
		state.platforms[10 + i].position = glm::vec3(-2.5, -2.25 + i, 0);
	}
	for (int i = 0; i < 2; i++) {
		state.platforms[13 + i].position = glm::vec3(0.5, -2.25 + i, 0);
	}
	//change some floor platforms to cheese
	for (int i = 0; i < 2; i++) {
		state.platforms[3 + i].entityType = CHEESE;
		state.platforms[3 + i].currentAnim = new int[1]{ 0 };
		state.platforms[8 + i].entityType = CHEESE;
		state.platforms[8 + i].currentAnim = new int[1]{ 0 };
	}
}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Magnificent Mouse!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
	glewInit();
#endif

	glViewport(0, 0, 640, 480);
	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
	//initialize state
	state.platforms = platforms;
	state.player = player;
	//initialize player
	initializePlayer();
	//initialize platforms
	initializePlatforms();
	//load texture id for font
	fontTextureID = LoadTexture("pixel_font.png");
	viewMatrix = glm::mat4(1.0f);
	modelMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

	glUseProgram(program.programID);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


	glClearColor((230.0f/255.0f), (255.0f/255.0f), (153.0f/255.0f),1.0f);
}

void ProcessInput() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
		case SDL_WINDOWEVENT_CLOSE:
			gameIsRunning = false;
			break;

		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
			case SDLK_SPACE:
				// restart the game
				if ((state.gameMode != GAME_PLAYING)
					|| (state.player.position.x > 5)
					|| (state.player.position.x < -5)) {
					state.player.position = glm::vec3(-3.5, 3.0, 0);
					state.player.velocity = glm::vec3(0, -0.1, 0);
					state.player.acceleration = glm::vec3(0, -0.1, 0);
					state.player.currentAnim = state.player.walkRight;
					glClearColor((230.0f / 255.0f), (255.0f / 255.0f), (153.0f / 255.0f), 1.0f);
					state.gameMode = GAME_PLAYING;
				}
				break;

			}
			break;
		}
	}

	if (state.gameMode == GAME_PLAYING) {
		state.player.acceleration.x = 0;
		// Check for pressed/held keys below
		const Uint8 *keys = SDL_GetKeyboardState(NULL);

		if (keys[SDL_SCANCODE_A])
		{
			state.player.acceleration.x = -0.5;
		}
		else if (keys[SDL_SCANCODE_D])
		{
			state.player.acceleration.x = 0.5;
		}
	}


}

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;

	deltaTime += accumulator;
	if (deltaTime < FIXED_TIMESTEP) {
		accumulator = deltaTime;
		return;
	}

	while (deltaTime >= FIXED_TIMESTEP) {
		// Update. Notice it's FIXED_TIMESTEP. Not deltaTime
		state.player.Update(FIXED_TIMESTEP, state.platforms, PLATFORM_COUNT);

		deltaTime -= FIXED_TIMESTEP;
	}

	accumulator = deltaTime;
}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);
	//draw all tiles
	for (int i = 0; i < PLATFORM_COUNT; i++) {
		state.platforms[i].Render(&program);
	}
	//draw player
	state.player.Render(&program);
	//draw text if applicable
	if (state.gameMode == GAME_LOSE) {
		DrawText(&program, fontTextureID, "You Lose :(", 0.6f, 0.01f, glm::vec3(-3.0f, 2.75f, 0.0f));
		DrawText(&program, fontTextureID, "Hit space to try again!", 0.2f, 0.005f, glm::vec3(-2.5f, 2.0f, 0.0f));
	}
	else if (state.gameMode == GAME_WIN) {
		DrawText(&program, fontTextureID, "You Win!", 0.6f, 0.01f, glm::vec3(-2.0f, 2.5f, 0.0f));
	}
	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		Update();
		Render();
	}

	Shutdown();
	return 0;
}