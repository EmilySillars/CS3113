#include "Entity.h"

Entity::Entity()
{
	entityType = CAT; //default
	isStatic = true; //default
	isActive = true; //default
	gameState = NULL;
	position = glm::vec3(0);
	speed = 0;
	width = 1.0f;
	height = 1.0f;
	spriteWidth = 1.0f;
	spriteHeight = 1.0f;

	animTime = 0;
	animIndex = 0;
}

bool Entity::CheckCollision(Entity other)
{
	if (isStatic) return false;
	if (isActive == false || other.isActive == false) return false;

	float xdist = fabs(position.x - other.position.x) - ((width + other.width) / 2.0f);
	float ydist = fabs(position.y - other.position.y) - ((height + other.height) / 2.0f);
	if (xdist < 0 && ydist < 0)
	{
		if (entityType == PLAYER && other.entityType == CAT
			&& getGameMode() == GAME_PLAYING ) {
		    setGameMode(GAME_LOSE);
			acceleration = glm::vec3(0, 0, 0);
			velocity = glm::vec3(0, 0, 0);
			glClearColor((153.0f / 255.0f), (204.0f / 255.0f), (255.0f / 255.0f), 1.0f);
		}
		if (entityType == PLAYER && other.entityType == CHEESE
			&& getGameMode() == GAME_PLAYING) {
			gameState-> gameMode = GAME_WIN;
			acceleration = glm::vec3(0, 0, 0);
			velocity = glm::vec3(0, 0, 0);
			glClearColor((255.0f / 255.0f), (223.0f / 255.0f), (128.0f / 255.0f), 1.0f);
		}
		return true;
	}

	return false;
}

void Entity::CheckCollisionsY(Entity *objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float ydist = fabs(position.y - object.position.y);
			float penetrationY = fabs(ydist - (height / 2) - (object.height / 2));
			if (velocity.y > 0) { //if it was going up,
				collidedTop = true;
				position.y -= penetrationY;
				velocity.y = 0;
			}
			else if (velocity.y < 0) { //if it was going down when it collided,
				collidedBottom = true;
				position.y += penetrationY;
				velocity.y = 0;
			}
		}
	}
}

void Entity::CheckCollisionsX(Entity *objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float xdist = fabs(position.x - object.position.x);
			float penetrationX = fabs(xdist - (width / 2) - (object.width / 2));
			if (velocity.x > 0) { //if it was going right
				collidedRight = true;
				position.x -= penetrationX;
				velocity.x = 0;
			}
			else if (velocity.x < 0) { //if it was going left
				collidedLeft = true;
				position.x += penetrationX;
				velocity.x = 0;
			}
		}
	}
}

void Entity::Jump() {
	if (collidedBottom) {
		velocity.y = 5.0f;
	}
}

void Entity::Update(float deltaTime, Entity *objects, int objectCount)
{
	if (getGameMode() == GAME_PLAYING) {
		//reset collision flags
		collidedTop = false;
		collidedBottom = false;
		collidedRight = false;
		collidedLeft = false;

		velocity += acceleration * deltaTime;

		position.y += velocity.y * deltaTime; // Move on Y
		CheckCollisionsY(objects, objectCount); // Fix if needed

		position.x += velocity.x * deltaTime; // Move on X
		CheckCollisionsX(objects, objectCount); // Fix if needed

		//update animation based on movement
		animTime += deltaTime;

		if (animTime >= 0.25f) //0.25 means 4 fps
		{
			animTime = 0;
			animIndex++;
			if (animIndex >= animFrames)
			{
				animIndex = 0;
			}
		}
	}
}

void Entity::DrawSpriteFromTextureAtlas(ShaderProgram *program, int index)
{
	float u = (float)(index % cols) / (float)cols;
	float v = (float)(index / cols) / (float)rows;

	float width = 1.0f / (float)cols;
	float height = 1.0f / (float)rows;

	float texCoords[] = { u, v + height, u + width, v + height, u + width, v,
		u, v + height, u + width, v, u, v };
	float x = spriteWidth / 2;
	float y = spriteHeight / 2;
	float vertices[] = { -1*x, -1*y, x, -1*y, x, y, -1*x, -1*y, x, y, -1*x, y };

	glBindTexture(GL_TEXTURE_2D, textureID);

	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program->positionAttribute);

	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(program->texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);
}

void Entity::Render(ShaderProgram *program) {
	glm::mat4 modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, position);
	program->SetModelMatrix(modelMatrix);
	if (acceleration.x < 0) {
		DrawSpriteFromTextureAtlas(program, walkLeft[animIndex]);
		currentAnim = walkLeft;
	}
	else if (acceleration.x > 0) {
		DrawSpriteFromTextureAtlas(program, walkRight[animIndex]);
		currentAnim = walkRight;
	}
	else {
		DrawSpriteFromTextureAtlas(program, currentAnim[animIndex]);
	}
}


void Entity::setGameMode(GameMode mode) {
	gameState->gameMode = mode;
}

GameMode Entity::getGameMode() {
	return gameState->gameMode;
}